Notes:
1) Create a new branch
2) Check out the project
3) modify the folder goodwin
4) create a new zip - goodwin.zip
5) check in the zip and all files within goodwin folder.
6) Release goodwin.zip to godaddy

At godaddy:
1) in local create zip - right click on goodwin folder and select sendto compressed zip folder. make sure the file name is goodwin.zip
1) upload goodwin.zip - overwrite the file which already exists in godaddy
2) extract the zip at godaddy. 